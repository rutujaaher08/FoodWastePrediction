# FoodWise — Food Waste Prediction and Smart Redistribution

## Project purpose
A responsive academic demo website for estimating potential food surplus and presenting sample smart-redistribution suggestions.

## Included features
- Responsive layout for mobile and desktop
- Interactive surplus estimator using prepared and expected-consumed portions
- Food categories: cooked meals, bakery items, produce, and packaged food
- Sample redistribution suggestions
- Mobile navigation
- Custom 404 page
- Netlify-ready static site configuration

## Important model limitation
The current estimator uses `prepared portions - expected consumed portions`. It is a transparent rule-based demo, not a trained AI/ML prediction model. For a genuine ML version, connect a validated model and real historical data. Donation cards are examples, not live listings or verified organizations.

## Run in VS Code
1. Extract the ZIP.
2. In VS Code choose **File > Open Folder** and select this folder.
3. Open `index.html` in a browser, or install the Live Server extension and select **Open with Live Server**.
4. In the estimator, enter prepared portions and expected consumed portions, then click **Estimate surplus food**.
5. Test the mobile menu and the redistribution suggestion buttons.

## Deploy on Netlify
1. Sign in at https://app.netlify.com/
2. Open https://app.netlify.com/drop
3. Upload the extracted folder containing `index.html`, `style.css`, `script.js`, and `404.html`.
4. Wait for the deploy to complete and copy the public URL ending in `netlify.app`.
5. Open the URL in a new browser tab and test the estimator.
6. Visit a made-up path such as `/missing-page-123` to test the custom 404 page.
7. Save the real public URL and screenshots for your practical record.

## Test cases
| Test | Expected result |
|---|---|
| Open home page | FoodWise home page loads |
| Enter 100 prepared and 75 consumed | Estimated surplus is 25 portions |
| Enter consumed greater than prepared | Validation message appears |
| Choose a redistribution suggestion | Food category is selected in estimator |
| Resize to mobile | Layout adapts and navigation menu works |
| Open an invalid deployed URL path | Custom 404 page is shown if supported by host |
| Open public URL on another device | Website is publicly accessible |

## Result
The FoodWise responsive demo can be tested locally and deployed as a static website. The deployed public URL should be recorded after successful hosting.

## Practical submission
Add your name, roll number, class, date, and actual deployed URL to your journal.
