const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});

navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

document.getElementById('predictionForm').addEventListener('submit', event => {
  event.preventDefault();
  const prepared = Number(document.getElementById('meals').value);
  const consumed = Number(document.getElementById('attendees').value);
  const category = document.getElementById('foodType').value;

  if (!Number.isFinite(prepared) || !Number.isFinite(consumed) || prepared < 1 || consumed < 0 || consumed > prepared) {
    document.getElementById('resultTitle').textContent = 'Please check your inputs';
    document.getElementById('surplusValue').textContent = '—';
    document.getElementById('resultText').textContent = 'Consumed meals must be zero or more and cannot exceed meals prepared.';
    return;
  }

  const surplus = prepared - consumed;
  document.getElementById('resultTitle').textContent = surplus ? 'Potential surplus identified' : 'No surplus estimated';
  document.getElementById('surplusValue').textContent = String(surplus);
  document.getElementById('resultText').textContent = surplus
    ? `The simple estimate suggests ${surplus} portions of ${category.toLowerCase()} may remain.`
    : 'Based on these inputs, all prepared portions are expected to be consumed.';
  document.getElementById('suggestion').textContent = surplus
    ? 'Check food safety and freshness, then contact a verified local food-support organization promptly.'
    : 'Continue tracking actual preparation and consumption to improve future planning.';
});

document.querySelectorAll('.text-button').forEach(button => {
  button.addEventListener('click', () => {
    document.getElementById('foodType').value = button.dataset.category;
    document.getElementById('predict').scrollIntoView({ behavior: 'smooth' });
  });
});

document.getElementById('year').textContent = new Date().getFullYear();
